v13: NO번호 일치, API 자동 적용, 실행중 오버레이, 상단 메뉴 스타일, 목록 hover 개선

v16: POP3 mail listing support via DEFAULT_MAIL_PROTOCOL=POP3 (.env: POP3_SERVER, POP3_EMAIL, POP3_PASSWORD). Dynamic client include in index.php. Added 'authorization' field to llm-api-list.json; llm_client.php now respects 'Bearer' or 'Basic' and merges custom headers.
