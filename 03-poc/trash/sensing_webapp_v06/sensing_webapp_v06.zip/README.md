# Gmail IMAP → OpenRouter LLM 센싱 자동화 (v06)

### 이번 변경
1) **팝업 리사이즈**: 우상단 팝업을 마우스로 크기 조절(`resize: both`) 가능
2) **LLM 분석 결과 HTML 렌더링**: 팝업에 `<iframe srcdoc=...>`로 HTML 그대로 표시
3) **프롬프트 저장 권한 오류 표시**: `prompt.txt` 저장 실패 시 에러 팝업으로 안내

다른 동작은 v05와 동일합니다.
